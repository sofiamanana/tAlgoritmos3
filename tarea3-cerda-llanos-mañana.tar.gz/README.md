# Tarea 3 Algoritmos y Complejidad

#### Integrantes:

- Alfredo Llanos 201804536-5
- Sofia Mañana 201804535-7
- Fernanda Cerda 201804567-5
    
#### Ejecución

- Para ejecutar, ejecutar en una terminal utilizando Python3 y indicando el nombre del archivo de prueba con < texto.txt
- texto.txt es el caso de prueba generado para este programa.
- Programa hecho en Ubuntu 20.04 con Python3.
   
